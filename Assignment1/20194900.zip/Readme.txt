Name: Chan Chi Hin
ID: 20194900

Instructions:
1. Run “javac StudentRecord.java” in command line
2. **Run “java StudentRecord” instead of “java Student”

Note: 
Default input file is set as “sample_input_1.txt”